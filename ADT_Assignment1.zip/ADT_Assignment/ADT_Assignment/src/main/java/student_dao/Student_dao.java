package student_dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import db_connectivity.DB_connectivity;
import student_bean.Student_bean;

public class Student_dao {
	DB_connectivity db=new DB_connectivity();
	Connection con=db.getConnectivity();
	int a=0;
	ResultSet rs=null;
	public int insert(Student_bean bn) {
		String q="INSERT INTO `student`( `student_name`, `student_DOB`, `student_DOJ`) VALUES (?,?,?)";
		
		try {
			PreparedStatement ps=con.prepareStatement(q);
			ps.setString(1, bn.getName());
			ps.setDate(2, bn.getSTUDENT_DOB());
			ps.setDate(3, bn.getSTDENT_JOB());
			a=ps.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return a;
	}
	public ResultSet fetch_student() {
		String q="select *from student";
		try {
			PreparedStatement ps=con.prepareStatement(q);
			
		rs=ps.executeQuery();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}
	public Student_bean update(Student_bean bn) {
		String q="SELECT * FROM `student` WHERE student_no=?";

		try {
			PreparedStatement ps=con.prepareStatement(q);
			ps.setInt(1, Integer.parseInt(bn.getId()));
			rs=ps.executeQuery();
			while(rs.next()) {
				System.out.println("rs value in update"+rs.getString(2));
				bn.setName(rs.getString(2));
				bn.setSTDENT_JOB(rs.getDate(4));
				bn.setSTUDENT_DOB(rs.getDate(3));
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bn;
	}
	public int update_student(Student_bean bn) {
		String q="UPDATE `student` SET `student_name`=?,`student_DOB`=?,`student_DOJ`=? WHERE `student_no`=?";
		try {
			System.out.println("in dao update student "+bn.getName()+","+bn.getSTDENT_JOB()+","+bn.getSTUDENT_DOB()+","+bn.getId());
			PreparedStatement ps=con.prepareStatement(q);
			ps.setString(1, bn.getName());
			ps.setDate(2, bn.getSTUDENT_DOB());
			ps.setDate(3, bn.getSTDENT_JOB());
			ps.setInt(4, Integer.parseInt(bn.getId()));
			
			a=ps.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return a;
	}
	public int delete(Student_bean bn) {
		String q="delete from student where `student_no`=?";
		try {
			PreparedStatement ps=con.prepareStatement(q);
			ps.setInt(1,Integer.parseInt(bn.getId() ));
			a=ps.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return a;
	}
}
