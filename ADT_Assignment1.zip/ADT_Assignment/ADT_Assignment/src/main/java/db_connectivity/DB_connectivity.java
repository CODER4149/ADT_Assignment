package db_connectivity;

import java.sql.Connection;
import java.sql.DriverManager;

public class DB_connectivity {
	Connection con=null;
	public Connection getConnectivity() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
			System.out.println("connection established:");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
}
