package student_servlet;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import student_bean.Student_bean;
import student_dao.Student_dao;

/**
 * Servlet implementation class delete
 */
@WebServlet("/delete")
public class delete extends HttpServlet {
	private static final long serialVersionUID = 1L;

  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id=request.getParameter("id");
		
		Student_bean bn=new Student_bean();
		bn.setId(id);
		
		Student_dao op=new Student_dao();
		int y=op.delete(bn);
		if(y==1) {
			request.setAttribute("msg", "record deleted");
			RequestDispatcher rd=request.getRequestDispatcher("/home.jsp");
			rd.include(request, response);
		}
		
	}

}
