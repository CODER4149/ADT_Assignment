package student_servlet;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import student_bean.Student_bean;
import student_dao.Student_dao;

/**
 * Servlet implementation class update
 */
@WebServlet("/update")
public class update extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id=request.getParameter("id");
		System.out.println("id in string"+id+"not null");
		Student_bean bn=new Student_bean();
		bn.setId(id);
		
		Student_dao op=new Student_dao();
		bn=op.update(bn);
		System.out.println("bean value="+bn.getName());
		if(bn!=null) {
			request.setAttribute("bean", bn);
			RequestDispatcher rd=request.getRequestDispatcher("/update.jsp");
			rd.include(request, response);
		}
	}

}
