package student_servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import student_bean.Student_bean;
import student_dao.Student_dao;

/**
 * Servlet implementation class Update_student
 */
@WebServlet("/Update_student")
public class Update_student extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("student_name"),
				DOB=request.getParameter("DOB"),
				DOJ=request.getParameter("joining"),
				id=request.getParameter("id");
		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); 
		java.util.Date dateStr;
		java.util.Date date=null;
		java.sql.Date dateDB=null,DOJ_DB=null;
		try {
			dateStr = formatter.parse(DOB);
			date=formatter.parse(DOJ);
			 dateDB = new java.sql.Date(dateStr.getTime());
			 DOJ_DB=new java.sql.Date(date.getTime());
		} catch (Exception e1) {
			
			e1.printStackTrace();
		}
		
		Student_bean bn=new Student_bean();
		bn.setId(id);
		bn.setName(name);
		bn.setSTUDENT_DOB(dateDB);
		bn.setSTDENT_JOB(DOJ_DB);
			
		Student_dao op=new Student_dao();
		int y=op.update_student(bn);
		
		if(y==1) {
			request.setAttribute("msg", "record updated");
			RequestDispatcher rd=request.getRequestDispatcher("/home.jsp");
			rd.include(request, response);
		}
	}

}
