package student_bean;

import java.sql.Date;

public class Student_bean {
	public String name,id;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Date STUDENT_DOB,STDENT_JOB;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getSTUDENT_DOB() {
		return STUDENT_DOB;
	}
	public void setSTUDENT_DOB(Date sTUDENT_DOB) {
		STUDENT_DOB = sTUDENT_DOB;
	}
	public Date getSTDENT_JOB() {
		return STDENT_JOB;
	}
	public void setSTDENT_JOB(Date sTDENT_JOB) {
		STDENT_JOB = sTDENT_JOB;
	}
}
